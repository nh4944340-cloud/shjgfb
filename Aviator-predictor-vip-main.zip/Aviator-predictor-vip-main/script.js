const firebaseConfig = {
  apiKey: "AIzaSyANQ-S9Z1decDy-XdQC7Y9p6iJ-CthM-SM",
  authDomain: "aviator-8111f.firebaseapp.com",
  projectId: "aviator-8111f",
  storageBucket: "aviator-8111f.appspot.com",
  messagingSenderId: "639531516539",
  appId: "1:639531516539:web:9832e8ea45fbb68bddf2"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

const depositPage = document.getElementById("depositPage");
const loginPage = document.getElementById("loginPage");
const homePage = document.getElementById("homePage");
const popup = document.getElementById("popupBox");

db.collection("settings").doc("nagad").get().then(d => {
  if (d.exists) {
    document.getElementById("nagadNumber").innerText = d.data().number;
  }
});

function copyNumber() {
  navigator.clipboard.writeText(document.getElementById("nagadNumber").innerText)
    .then(() => alert("নাম্বার কপি হয়েছে!"));
}

function submitDeposit() {
  const phone = document.getElementById("phone").value.trim();
  const trx = document.getElementById("trx").value.trim();
  if (!phone || !trx) {
    document.getElementById("statusMsg").innerText = "⚠️ সব ঘর পূরণ করুন";
    return;
  }

  popup.style.display = "block";
  const userID = 'ID-' + Math.floor(Math.random() * 100000);
  const password = 'PASS-' + Math.floor(100000 + Math.random() * 900000);

  db.collection("deposits").add({
    phone, trx, approved: false, userID, password,
    timestamp: firebase.firestore.FieldValue.serverTimestamp()
  }).then(ref => {
    listenForApproval(ref.id, userID, password);
  });
}

function listenForApproval(docId, uid, pass) {
  localStorage.setItem("aviatorDoc", docId);
  db.collection("deposits").doc(docId).onSnapshot(d => {
    if (d.exists && d.data().approved) {
      popup.style.display = "none";
      finishLogin(d.data().userID, d.data().password);
      localStorage.setItem("aviatorApproved", "true");
    }
  });
}

function finishLogin(uid, pass) {
  depositPage.classList.add("hidden");
  loginPage.classList.remove("hidden");
  document.getElementById("loginID").value = uid;
  document.getElementById("loginPass").value = pass;
  localStorage.setItem("aviatorUID", uid);
  localStorage.setItem("aviatorPASS", pass);
}

window.addEventListener("load", () => {
  if (localStorage.getItem("aviatorApproved") === "true") {
    finishLogin(localStorage.getItem("aviatorUID"), localStorage.getItem("aviatorPASS"));
  }
});

function showHomePage() {
  loginPage.classList.add("hidden");
  homePage.classList.remove("hidden");
  runRound();
}

const barFill = document.getElementById("barFill");
const betMsg = document.getElementById("betMessage");
const multEl = document.getElementById("multiplier");
const circle = document.getElementById("progressCircle");
const R = 90, C = 2 * Math.PI * R;
circle.style.strokeDasharray = C;
circle.style.strokeDashoffset = C;

function drawCircle(p) {
  circle.style.strokeDashoffset = C - C * p / 100;
}

function genMultip() {
  return (1 + Math.random() * 10).toFixed(2);
}

function runRound() {
  const mult = genMultip();
  multEl.textContent = mult + 'x';
  betMsg.style.display = 'block';
  let w = 0, p = 0;
  barFill.style.width = '0%'; drawCircle(0);
  const step = setInterval(() => {
    w += 100 / 120;
    p += 100 / 120;
    barFill.style.width = w + '%';
    drawCircle(p);
    if (w >= 100) {
      clearInterval(step);
      betMsg.style.display = 'none';
      setTimeout(runRound, parseFloat(mult) * 1000);
    }
  }, 100);
}
